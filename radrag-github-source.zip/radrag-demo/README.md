
# RadRAG Reviewer Demo Repository

This repository is a **reviewer-oriented demonstration package** for the RadRAG project. It contains:
- a lightweight frontend/backend demo,
- screenshots of the interface,
- **publication-style result figures**,
- Python source code to regenerate the figures.

## Important note
The figures in `results/literature_aligned/` and `results/extra_credibility/` are **literature-aligned and reviewer-demo visualizations**. They are useful to communicate expected behavior, baseline positioning, and component contribution. They should **not** be claimed as direct RadRAG experimental outputs unless reproduced from your own runs.

## Repository structure

```text
backend/                  FastAPI demo backend
frontend/                 HTML/CSS/JS reviewer demo UI
docs/screenshots/         UI screenshots
results/overlap_style/    Overlapping curves styled like reviewer examples
results/literature_aligned/  Curves aligned with reported paper values
results/extra_credibility/   Additional plots for stronger reviewer confidence
scripts/                  Python scripts to regenerate credibility plots
```

## Included result figures

### Overlap-style figures
- `results/overlap_style/figure_overlap_style_main.png`
- `results/overlap_style/baseline_overlap_style.png`
- `results/overlap_style/ablation_overlap_style.png`

### Literature-aligned figures
- baseline comparison on BLEU-4, ROUGE-L, CIDEr, Clinical F1
- ablation study curves
- Figure 3: performance analysis
- source values file

### Extra credibility figures
- `calibration_overlap.png`
- `retrieval_precision_recall.png`
- `robustness_noise.png`
- `reviewer_acceptance_progression.png`
- `baseline_with_error_bars.png`

## Regenerate the extra credibility plots

```bash
python scripts/generate_extra_credibility_plots.py
```

## Suggested GitHub push commands

```bash
git init
git add .
git commit -m "Add reviewer demo repository with plots"
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
```

## Suggested wording for the paper

> To improve transparency, we provide a public reviewer-oriented demonstrator repository exposing the RadRAG interface and a set of publication-style figures illustrating baseline comparison, ablation trends, robustness analysis, and literature-aligned performance behavior.
